from django.apps import AppConfig


class LikesBooksConfig(AppConfig):
    name = 'likes_books'
